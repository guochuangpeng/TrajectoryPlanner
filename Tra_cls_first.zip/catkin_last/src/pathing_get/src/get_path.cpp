#include "get_path.h"

get_path::get_path()
{
ros::NodeHandle nh_private("~");
 if (!nh_private.getParam("route", param_list)) 
{ROS_ERROR("Failed to load parameter from servel.");}
ptnums = param_list.size() / 3;
//用route_ref、route记录中间点的数据，.resize用来初始化容器大小，数据格式3*个数？
route_ref.resize(3, ptnums);
route.resize(3, ptnums);
//不断读取并将中间点的内容，存入route_ref中
for (int i = 0; i < param_list.size(); i++) 
{
  XmlRpc::XmlRpcValue tmp_value = param_list[i];
  if (tmp_value.getType() == XmlRpc::XmlRpcValue::TypeDouble) 
  {
    route_ref(i/ptnums, i%ptnums) = double(tmp_value);
  }
}
//将值传给route
route = route_ref;
//判断配置文件中的 ts 参数列表是否为空
if (!nh_private.getParam("ts", param_list)) 
{
  ROS_ERROR("Failed to load parameter from servel.");
}
//初始化时间分配值ts容器大小，记录ts数据
ts.resize(ptnums-1);
//往容器里面提取参数列表数据
for (int i = 0; i < param_list.size(); i++) 
{
  XmlRpc::XmlRpcValue tmp_value = param_list[i];
  if (tmp_value.getType() == XmlRpc::XmlRpcValue::TypeDouble) 
  {
    ts(i) = double(tmp_value);
  }
}
//创建k、p、i参数变量，并通过yaml文件读取参数
double kp_pos_h, kp_vel_h, ki_vel_h, kd_vel_h;
double kp_pos_z, kp_vel_z, ki_vel_z, kd_vel_z;
double kp_pose;
//读取控制器参数
  nh_private.getParam("if_PID", if_PID);
  nh_private.getParam("delay", delay);
  ts *= delay;
  nh_private.getParam("max_vel", max_vel);
  nh_private.getParam("max_acc", max_acc);
  nh_private.getParam("kp_pos_h", kp_pos_h);
  nh_private.getParam("kp_vel_h", kp_vel_h);
  nh_private.getParam("ki_vel_h", ki_vel_h);
  nh_private.getParam("kd_vel_h", kd_vel_h);
  nh_private.getParam("kp_pos_z", kp_pos_z);
  nh_private.getParam("kp_vel_z", kp_vel_z);
  nh_private.getParam("ki_vel_z", ki_vel_z);
  nh_private.getParam("kd_vel_z", kd_vel_z);
  nh_private.getParam("kp_pose", kp_pose);
  nh_private.getParam("set_param_flag", set_param_flag);
  nh_private.getParam("debug_pos_x", debug_pos_desire(0));
  nh_private.getParam("debug_pos_y", debug_pos_desire(1));
  nh_private.getParam("debug_pos_z", debug_pos_desire(2));
//将读取到的值初始化到控制器中
controller1.setParam( Eigen::Vector2d(kp_pos_h, kp_pos_h),
                        Eigen::Vector2d(kp_vel_h, kp_vel_h),
                        Eigen::Vector2d(ki_vel_h, ki_vel_h),
                        Eigen::Vector2d(kd_vel_h, kd_vel_h),
                        kp_pos_z,
                        kp_vel_z,
                        ki_vel_z,
                        kd_vel_z,
                        Eigen::Vector3d(kp_pose, kp_pose, kp_pose));
controller1.max_vel = max_vel;
show_param();
generate_path();
}

void get_path::generate_path() 
{
  min_jerk::JerkOpt jerkOpt;
  Eigen::Matrix3d iS, fS;

  iS.setZero();
  fS.setZero();
  iS.col(0) << route.leftCols<1>();
  fS.col(0) << route.rightCols<1>();

  jerkOpt.reset(iS, fS, route.cols() - 1);
  jerkOpt.generate(route.block(0, 1, 3, route.cols() - 2), ts);
  jerkOpt.getTraj(minJerkTraj);
  cout<<"已规划路径，采用minimum—jerk算法:"<<endl;
}

void get_path::show_param()
{
  using namespace std;
  cout<<"读取配置文件成功"<<endl;
  cout<<"经过的点个数为:"<<endl;
  ROS_INFO("ptnums =  %d ", ptnums);
  
}