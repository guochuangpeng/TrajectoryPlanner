#ifndef GET_PATH_H
#define GET_PATH_H

#include "config.h"
#include "controller.h"
#include "traj_min_jerk.hpp"

class get_path
{
private:
public:
   //创建整数型变量记录中间点的个数
int ptnums;
//创建参数队列读取中间点的信息
XmlRpc::XmlRpcValue param_list;
//最大速度、最大加速度
double max_vel, max_acc;
//参数设置标记位
bool set_param_flag;
//路径点容器
Eigen::MatrixXd route_ref, route;
//期望路径
Eigen::Vector3d debug_pos_desire;
//路径时间
Eigen::VectorXd ts;
//定义delay类型
double delay;
//创建k、p、i参数变量，并通过yaml文件读取参数
double kp_pos_h, kp_vel_h, ki_vel_h, kd_vel_h;
double kp_pos_z, kp_vel_z, ki_vel_z, kd_vel_z;
double kp_pose;
//实例化一个control对象
control controller1;
//实例化一个minimum对象存储路径
min_jerk::Trajectory minJerkTraj;
//选择是否用PID
bool if_PID;

public:
//构建析构函数，在创建实例化对象时直接调用
get_path();
void generate_path();
void show_param();
};


#endif // CONFIG_H