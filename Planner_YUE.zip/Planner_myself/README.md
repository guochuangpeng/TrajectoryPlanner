### Get_param
### trajectory_generation
